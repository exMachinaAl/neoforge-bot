// tests/inv.test.js - SNBT, nama item, inv.snapshot / inv.view / inv.store / inv.take (bot tiruan, tanpa server)
const fs = require('fs'); const os = require('os'); const path = require('path')
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'arcadia-inv-'))
process.env.ARCADIA_DATA_DIR = TMP // sebelum modul lain dimuat: itemmap.json/snapshot*.json masuk folder sementara
const { mk, mkBlock, mcData, it } = require('./mock')
const snbt = require('../skills/_snbt')
const names = require('../skills/_names')
const U = require('../skills/_util')
const { createRunner } = require('../skills')
const { createEngine } = require('../engine')
let pass = 0; let fail = 0
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m) }
const sleep = ms => new Promise(r => setTimeout(r, ms))

// ---------- tiruan server: teks /data get ... ----------
const mcToNbt = s => s >= 36 && s <= 44 ? s - 36 : s >= 9 && s <= 35 ? s : s >= 5 && s <= 8 ? 103 - (s - 5) : s === 45 ? -106 : null
const comps = c => c ? ', components: {' + Object.entries(c).map(([k, v]) => '"' + k + '": ' + (typeof v === 'string' ? '"' + v + '"' : JSON.stringify(v))).join(', ') + '}' : ''
const itemTxt = (slotTxt, e) => '{Slot: ' + slotTxt + ', id: "' + e.id + '", count: ' + e.count + comps(e.comps) + '}'

function mkInv (o = {}) {
  const b = mk({ blocks: o.blocks || [mkBlock('chest', 3, 64, 0)] })
  b.username = 'BotAlpha'
  const slots = new Array(46).fill(null)
  b.inventory = { slots, items: () => slots.filter(i => i && i.count > 0), count: type => slots.filter(i => i && i.type === type).reduce((a, i) => a + i.count, 0) }
  const idOf = n => (it(n) ? it(n).id : null)
  b.put = (slot, name, count, type) => { const known = idOf(name); slots[slot] = { type: known != null ? known : type, name: known != null ? name : 'unknown', count, slot } }
  for (const [slot, [name, count, type]] of Object.entries(o.inv || {})) b.put(Number(slot), name, count, type)
  const chest = new Array(27).fill(null)
  for (const [slot, [name, count]] of Object.entries(o.chest || {})) chest[Number(slot)] = { type: idOf(name), name, count, slot: Number(slot) }
  b._chest = chest
  b.hiddenInv = o.hiddenInv || [] // ada di server, tak terbaca bot (mis. paket bermuatan komponen modded dibuang)
  b.hiddenChest = o.hiddenChest || []
  b.srv = { noOp: !!o.noOp, silent: !!o.silent, garbage: !!o.garbage, invOverride: o.invOverride }
  const say = t => setTimeout(() => b.emit('messagestr', t, 'system', {}), 5)
  b.chat = text => {
    b.sent = (b.sent || []).concat(text)
    if (b.srv.silent) return
    if (b.srv.noOp && text.startsWith('/data')) return say('Unknown or incomplete command, see below for error')
    if (/^\/data get entity BotAlpha Inventory/.test(text)) {
      if (b.srv.garbage) return say('BotAlpha has the following entity data: [{Slot: 0b, id: "minecraft:st')
      const truth = []
      slots.forEach((i, s) => { if (i && i.count > 0 && mcToNbt(s) != null) truth.push({ s: mcToNbt(s), id: i.name === 'unknown' ? (b.srv.invOverride && b.srv.invOverride[s]) || 'mod:unknown' : 'minecraft:' + i.name, count: i.count }) })
      b.hiddenInv.forEach(h => truth.push({ s: h.nbtSlot, id: h.id, count: h.count, comps: h.comps }))
      if (!truth.length) return say('Found no elements matching Inventory')
      return say('BotAlpha has the following entity data: [' + truth.map(e => itemTxt(e.s + 'b', e)).join(', ') + ']')
    }
    const m = /^\/data get block (-?\d+) (-?\d+) (-?\d+) Items/.exec(text)
    if (m) {
      const items = chest.map((i, s) => i && { s, id: 'minecraft:' + i.name, count: i.count }).filter(Boolean).concat(b.hiddenChest.map(h => ({ s: h.slot, id: h.id, count: h.count, comps: h.comps })))
      if (!items.length) return say('Found no elements matching Items')
      return say(m[1] + ', ' + m[2] + ', ' + m[3] + ' has the following block data: [' + items.map(e => itemTxt(e.s + 'b', e)).join(', ') + ']')
    }
  }
  const room = (type) => { // slot tujuan di inventory 9..44
    for (let s = 9; s <= 44; s++) if (slots[s] && slots[s].type === type && slots[s].count < 64) return s
    for (let s = 9; s <= 44; s++) if (!slots[s]) return s
    return -1
  }
  b.openContainer = async () => ({
    inventoryStart: 27,
    containerItems: () => chest.filter(Boolean).map(c => ({ ...c })),
    deposit: async (type, meta, n) => {
      let left = n; let moved = 0
      for (let s = 9; s <= 44 && left > 0; s++) {
        const x = slots[s]; if (!x || x.type !== type) continue
        let take = Math.min(left, x.count)
        const cs = chest.findIndex(c => c && c.type === type && c.count < 64); const cf = cs >= 0 ? cs : chest.findIndex(c => !c)
        if (cf < 0) break
        const cap = chest[cf] ? 64 - chest[cf].count : 64; take = Math.min(take, cap)
        if (!chest[cf]) chest[cf] = { type, name: x.name, count: 0, slot: cf }
        chest[cf].count += take; x.count -= take; if (x.count <= 0) slots[s] = null
        left -= take; moved += take
      }
      if (!moved) throw new Error('destination full')
    },
    withdraw: async (type, meta, n) => {
      let left = n; let moved = 0
      for (let s = 0; s < 27 && left > 0; s++) {
        const c = chest[s]; if (!c || c.type !== type) continue
        const ds = room(type); if (ds < 0) break
        const take = Math.min(left, c.count, slots[ds] ? 64 - slots[ds].count : 64)
        if (!slots[ds]) slots[ds] = { type, name: c.name, count: 0, slot: ds }
        slots[ds].count += take; c.count -= take; if (c.count <= 0) chest[s] = null
        left -= take; moved += take
      }
      if (!moved) throw new Error('destination full')
    },
    close () { b._closed = (b._closed || 0) + 1 }
  })
  return b
}
const inv = (b, name) => b.inventory.slots.filter(i => i && (i.name === name)).reduce((a, i) => a + i.count, 0)
const chestCount = (b, name) => b._chest.filter(i => i && i.name === name).reduce((a, i) => a + i.count, 0)

;(async () => {
  let b, r, o

  // ================= SNBT =================
  let v = snbt.extract('BotAlpha has the following entity data: [{Slot: 0b, id: "minecraft:iron_pickaxe", count: 1, components: {"minecraft:damage": 12, "minecraft:enchantments": {levels: {"minecraft:efficiency": 3}}}}, {Slot: -106b, id: "minecraft:shield", count: 1}]')
  let items = snbt.inventoryItems(v)
  ok(items.length === 2 && items[0].slot === 36 && items[0].id === 'minecraft:iron_pickaxe' && items[0].comps.join() === 'minecraft:damage,minecraft:enchantments' && items[1].slot === 45, 'SNBT: inventory 1.21 (count/id/components, slot hotbar 0b -> 36, tangan kiri -106b -> 45)')
  v = snbt.parse('{a: [I; -1, 2, 3], b: 1.5f, c: 2.0d, d: 5L, e: true, f: "x\\"y", g: \'it\\\'s\', h: [B; 1b, 2b], i: 9007199254740993L, j: -7s, k: 1e3, l: minecraft:stone}')
  ok(v.a.join() === '-1,2,3' && v.b === 1.5 && v.c === 2 && v.d === 5 && v.e === true && v.f === 'x"y' && v.g === "it's" && v.h.join() === '1,2' && v.i === '9007199254740993' && v.j === -7 && v.k === 1000 && v.l === 'minecraft:stone', 'SNBT: tipe angka, array bertipe, boolean, escape, long tak aman jadi string, token tanpa kutip')
  v = snbt.parse('[\n  { Slot : 1b ,\n    id : "minecraft:dirt" , count : 4 , } ,\n]')
  ok(Array.isArray(v) && v.length === 1 && v[0].Slot === 1 && v[0].count === 4, 'SNBT: toleran spasi, baris baru, koma penutup')
  let threw = false; try { snbt.extract('x has the following entity data: [{Slot: 0b, id: "minec') } catch (e) { threw = /SNBT/.test(e.message) }
  ok(threw, 'SNBT: data terpotong -> error jelas')
  threw = false; try { snbt.extract('tidak ada data') } catch (e) { threw = true }
  ok(threw, 'SNBT: teks tanpa [ atau { -> error')
  ok([[0, 36], [8, 44], [9, 9], [35, 35], [100, 8], [101, 7], [102, 6], [103, 5], [-106, 45]].every(([n, s]) => snbt.nbtSlotToMc(n) === s) && snbt.nbtSlotToMc(50) === null, 'slot NBT -> slot jendela (hotbar, utama, armor, tangan kiri)')
  let deep = '{a:'.repeat(70) + '1' + '}'.repeat(70); threw = false; try { snbt.parse(deep) } catch (e) { threw = /dalam/.test(e.message) }
  ok(threw, 'SNBT: kedalaman berlebih ditolak')

  // ================= nama item =================
  names.load([{ key: 'touhou_little_maid:bell', value: 9999 }])
  ok(U.itemKey({ name: 'unknown', type: 9999 }) === 'touhou_little_maid:bell' && U.itemKey({ name: 'unknown', type: 8888 }) === 'unknown#8888' && U.itemKey({ name: 'bread', type: 1 }) === 'bread', 'itemKey: nama dari registri sinkronisasi, cadangan unknown#id, vanilla tetap')
  names.load([])

  // ================= inv.snapshot =================
  b = mkInv({ inv: { 36: ['cobblestone', 37], 37: ['iron_pickaxe', 1], 12: ['coal', 5] } }); r = createRunner(b)
  ok(['inv.snapshot', 'inv.view', 'inv.store', 'inv.take'].every(n => r.skills[n]), 'runner memuat 4 skill inventory')
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.accurate && o.data.matched === 3 && o.data.serverItems === 3 && b.arcadia.inventoryTruth.accurate, 'snapshot: inventory cocok -> accurate=true (3 item)')
  ok(fs.existsSync(path.join(TMP, 'snapshot.json')) && JSON.parse(fs.readFileSync(path.join(TMP, 'snapshot.json'), 'utf8')).accurate === true, 'snapshot: snapshot.json ditulis')
  ok(b.sent[0] === '/data get entity BotAlpha Inventory', 'snapshot: perintah yang dikirim benar')

  b = mkInv({ inv: { 36: ['cobblestone', 37] }, hiddenInv: [{ nbtSlot: 5, id: 'sophisticatedbackpacks:backpack', count: 1, comps: { 'sophisticatedbackpacks:storage_contents': 'x' } }] }); r = createRunner(b)
  o = await r.run('inv.snapshot', {})
  ok(o.ok && !o.data.accurate && o.data.missingInBot.length === 1 && o.data.missingInBot[0].modded === true && o.data.missingInBot[0].id === 'sophisticatedbackpacks:backpack' && /hilang di bot/.test(o.data.note) && b.arcadia.inventoryTruth.accurate === false, 'snapshot: item modded tak terbaca bot terdeteksi (missingInBot, modded=true, accurate=false)')
  ok(o.data.moddedOrComponent.length === 1 && o.data.moddedOrComponent[0].comps[0] === 'sophisticatedbackpacks:storage_contents', 'snapshot: item bermuatan komponen modded dilaporkan beserta nama komponennya')

  b = mkInv({ hiddenInv: [{ nbtSlot: 0, id: 'minecraft:dirt', count: 3 }] }); r = createRunner(b)
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.protocolEmpty === true && !o.data.accurate, 'snapshot: inventory bot kosong padahal server berisi -> protocolEmpty')

  b = mkInv({ inv: { 36: ['cobblestone', 40] } }); r = createRunner(b)
  const c0 = b.chat
  b.chat = text => /Inventory/.test(text) ? setTimeout(() => b.emit('messagestr', 'BotAlpha has the following entity data: [{Slot: 0b, id: "minecraft:cobblestone", count: 37}]', 'system', {}), 5) : c0(text)
  o = await r.run('inv.snapshot', {})
  ok(o.ok && !o.data.accurate && o.data.countDiff.length === 1 && o.data.countDiff[0].bot === 40 && o.data.countDiff[0].server === 37, 'snapshot: selisih jumlah (bot 40, server 37) dilaporkan')

  b = mkInv({ inv: { 36: ['dirt', 2] }, invOverride: null }); b.put(20, 'unknown', 2, 9999); b.srv.invOverride = { 20: 'touhou_little_maid:bell' }; r = createRunner(b)
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.learned['9999'] === 'touhou_little_maid:bell' && o.data.unknownNamed.length === 1, 'snapshot: unknown#9999 dipelajari sebagai touhou_little_maid:bell')
  ok(U.itemKey({ name: 'unknown', type: 9999 }) === 'touhou_little_maid:bell' && JSON.parse(fs.readFileSync(path.join(TMP, 'itemmap.json'), 'utf8'))['9999'] === 'touhou_little_maid:bell', 'snapshot: nama hasil belajar dipakai itemKey dan disimpan ke itemmap.json')
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.accurate && o.data.matched === 2 && o.data.unknownNamed.length === 0, 'snapshot ulang: id sudah dikenal -> cocok penuh (2 item)')

  b = mkInv({ noOp: true }); r = createRunner(b); o = await r.run('inv.snapshot', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /\/op BotAlpha/.test(o.error), 'snapshot: bot bukan op -> PRECONDITION_FAILED + petunjuk /op')
  b = mkInv({ silent: true }); r = createRunner(b); o = await r.run('inv.snapshot', { waitMs: 1000 })
  ok(!o.ok && o.code === 'TIMEOUT' && /sendCommandFeedback/.test(o.error), 'snapshot: tanpa balasan -> TIMEOUT (sebut gamerule)')
  b = mkInv({}); r = createRunner(b); o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.accurate && o.data.serverItems === 0, 'snapshot: inventory kosong ("Found no elements") -> OK, cocok')
  b = mkInv({ inv: { 36: ['dirt', 1] }, garbage: true }); r = createRunner(b); o = await r.run('inv.snapshot', {})
  ok(!o.ok && o.code === 'PROTOCOL_UNSUPPORTED' && fs.existsSync(path.join(TMP, 'snapshot_raw.txt')) && /minecraft:st/.test(fs.readFileSync(path.join(TMP, 'snapshot_raw.txt'), 'utf8')), 'snapshot: format tak terbaca -> PROTOCOL_UNSUPPORTED + teks mentah disimpan')

  // ================= inv.view =================
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12], 5: ['bread', 3] } }); r = createRunner(b)
  o = await r.run('inv.view', {})
  ok(o.ok && o.data.used === 3 && o.data.free === 24 && o.data.totals['minecraft:coal'] === 50 && o.data.verify.checked && o.data.verify.ok && b._closed === 1, 'view: 3 stack, 24 slot bebas, verifikasi server cocok, jendela ditutup')
  b = mkInv({ chest: { 0: ['coal', 50] }, hiddenChest: [{ slot: 3, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }] }); r = createRunner(b)
  o = await r.run('inv.view', {})
  ok(o.ok && o.data.verify.checked && !o.data.verify.ok && o.data.verify.missingInWindow.length === 1 && o.data.verify.missingInWindow[0].id === 'tacz:modern_kinetic_gun' && o.data.verify.missingInWindow[0].modded && /tak terbaca/.test(o.data.note), 'view: item modded yang hilang dari jendela terdeteksi lewat /data get block')
  b = mkInv({ chest: { 0: ['coal', 1] }, noOp: true }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(o.ok && o.data.verify.checked === false && /op/.test(o.data.verify.reason) && o.data.used === 1, 'view: tanpa op tetap menampilkan isi (verify dilewati dengan alasan)')
  b = mkInv({ chest: { 0: ['coal', 1] } }); r = createRunner(b); o = await r.run('inv.view', { verify: false })
  ok(o.ok && o.data.verify.checked === false && !(b.sent || []).length, 'view: verify=false tidak mengirim perintah')
  b = mkInv({ blocks: [] }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(!o.ok && o.code === 'TARGET_NOT_FOUND', 'view: tanpa chest -> TARGET_NOT_FOUND')
  const dbl = mkBlock('chest', 3, 64, 0); dbl.getProperties = () => ({ type: 'left' })
  b = mkInv({ blocks: [dbl], chest: { 0: ['coal', 1] } }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(o.ok && o.data.verify.checked === false && /ganda/.test(o.data.verify.reason), 'view: chest ganda -> verifikasi dilewati dengan alasan')
  b = mkInv({ chest: { 0: ['coal', 1] } }); r = createRunner(b); o = await r.run('inv.view', { chest: '3,64,0' })
  ok(o.ok && o.data.chest.how === 'koordinat', 'view: chest lewat koordinat teks "3,64,0"')

  // ================= inv.store =================
  const stash = () => ({ 9: ['cobblestone', 64], 10: ['cobblestone', 36], 11: ['dirt', 10], 12: ['iron_pickaxe', 1], 13: ['bread', 5], 14: ['unknown', 2, 9999], 36: ['stone_sword', 1] })
  b = mkInv({ inv: stash() }); r = createRunner(b)
  o = await r.run('inv.store', {})
  ok(o.ok && o.data.moved.cobblestone === 100 && o.data.moved.dirt === 10 && o.data.moved.bread === 5 && o.data.movedTotal === 115, 'store: default memindahkan semua vanilla (cobblestone 100 dari 2 stack, dirt 10, bread 5)')
  ok(inv(b, 'iron_pickaxe') === 1 && inv(b, 'stone_sword') === 1 && o.data.skipped.some(s => s.item === 'iron_pickaxe' && s.why === 'alat'), 'store: alat/senjata tetap di bot (keepTools)')
  ok(b.inventory.slots[14] && b.inventory.slots[14].count === 2 && o.data.skipped.some(s => s.why === 'modded'), 'store: item modded dilewati secara default')
  ok(chestCount(b, 'cobblestone') === 100 && o.data.chestAfter.totals['minecraft:cobblestone'] === 100 && o.data.verify.checked && o.data.verify.ok && o.data.verify.serverTotals['minecraft:dirt'] === 10, 'store: chest berisi sesuai, verifikasi server cocok')
  b = mkInv({ inv: stash() }); r = createRunner(b); o = await r.run('inv.store', { items: 'iron_pickaxe,dirt' })
  ok(o.ok && o.data.moved.iron_pickaxe === 1 && o.data.moved.dirt === 10 && !o.data.moved.cobblestone, 'store: daftar eksplisit menimpa keepTools dan hanya memindah yang disebut')
  b = mkInv({ inv: stash() }); r = createRunner(b); o = await r.run('inv.store', { keep: 'bread,dirt' })
  ok(o.ok && !o.data.moved.bread && !o.data.moved.dirt && o.data.moved.cobblestone === 100, 'store: keep menahan item tertentu')
  b = mkInv({ inv: stash() }); r = createRunner(b); o = await r.run('inv.store', { items: 'cobblestone,diamond' })
  ok(o.ok && o.data.moved.cobblestone === 100 && o.data.skipped.some(s => s.item === 'diamond' && /tidak ada/.test(s.why)), 'store: item yang diminta tapi tidak dimiliki dilaporkan')
  b = mkInv({ inv: stash(), chest: Object.fromEntries(Array.from({ length: 27 }, (_, i) => [i, ['gravel', 64]])) }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /penuh/.test(o.error) && o.data.chestFull && inv(b, 'cobblestone') === 100, 'store: chest penuh -> gagal jelas, tidak ada item hilang')
  b = mkInv({ inv: { 9: ['cobblestone', 64], 10: ['cobblestone', 36] }, chest: Object.assign(Object.fromEntries(Array.from({ length: 26 }, (_, i) => [i, ['gravel', 64]])), {}) }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(o.ok && o.data.moved.cobblestone === 64 && o.data.failed.length === 1 && /64\/100/.test(o.data.failed[0].error) && inv(b, 'cobblestone') + chestCount(b, 'cobblestone') === 100, 'store: chest hampir penuh -> sebagian terpindah (64/100), jumlah total tetap 100')
  b = mkInv({ inv: { 36: ['iron_pickaxe', 1] } }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /tidak ada item/.test(o.error), 'store: hanya alat -> tidak ada yang dipindah')
  b = mkInv({ inv: stash(), blocks: [] }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'TARGET_NOT_FOUND' && inv(b, 'cobblestone') === 100, 'store: tanpa chest -> TARGET_NOT_FOUND, inventory utuh')
  b = mkInv({ inv: stash(), noOp: true }); r = createRunner(b); o = await r.run('inv.store', { items: 'dirt' })
  ok(o.ok && o.data.moved.dirt === 10 && o.data.verify.checked === false, 'store: tanpa op tetap memindah, verifikasi server dilewati')
  b = mkInv({ inv: { 14: ['unknown', 2, 7777] } }); r = createRunner(b); o = await r.run('inv.store', { includeModded: true })
  ok(o.ok && o.data.moved['unknown#7777'] === 2, 'store: includeModded=true ikut memindah item modded (dicoba)')
  b = mkInv({ inv: { 0: ['dirt', 3], 5: ['dirt', 9], 45: ['dirt', 4], 9: ['dirt', 1] } }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(o.ok && o.data.moved.dirt === 1 && b.inventory.slots[5].count === 9 && b.inventory.slots[45].count === 4 && b.inventory.slots[0].count === 3, 'store: slot crafting/armor/tangan kiri tidak disentuh')

  // ================= inv.take =================
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12], 2: ['coal', 20] } }); r = createRunner(b)
  o = await r.run('inv.take', { item: 'coal', count: 60 })
  ok(o.ok && o.data.moved.coal === 60 && inv(b, 'coal') === 60 && chestCount(b, 'coal') === 10 && o.data.verify.ok && o.data.chestAfter.totals['minecraft:coal'] === 10, 'take: 60 coal dari 2 stack, sisa 10 di chest, verifikasi server cocok')
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal,iron_ingot', count: 'all' })
  ok(o.ok && o.data.moved.coal === 50 && o.data.moved.iron_ingot === 12 && chestCount(b, 'coal') === 0, 'take: dua item sekaligus dengan count=all')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal', count: 99 })
  ok(o.ok && o.data.moved.coal === 5, 'take: minta lebih dari ada -> ambil semua yang ada')
  b = mkInv({ chest: { 0: ['coal', 5], 1: ['bread', 2] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'diamond' })
  ok(!o.ok && o.code === 'TARGET_NOT_FOUND' && /tidak ada di chest: diamond/.test(o.error) && /coal x5/.test(o.error) && /bread x2/.test(o.error), 'take: item tak ada -> TARGET_NOT_FOUND + daftar isi chest')
  b = mkInv({ chest: { 0: ['coal', 5] }, inv: Object.fromEntries(Array.from({ length: 36 }, (_, i) => [i + 9, ['cobblestone', 64]])) }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal' })
  ok(!o.ok && o.code === 'INVENTORY_FULL' && chestCount(b, 'coal') === 5, 'take: inventory penuh -> INVENTORY_FULL, chest utuh')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'touhou_little_maid:bell' })
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /includeModded/.test(o.error), 'take: item modded tanpa includeModded -> PRECONDITION_FAILED')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', {})
  ok(!o.ok, 'take: tanpa param item ditolak')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal', count: 2, verify: false })
  ok(o.ok && o.data.moved.coal === 2 && o.data.verify.checked === false && !(b.sent || []).length, 'take: verify=false -> tanpa perintah ke server')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal' })
  ok(r.parse('inv.take', ['coal', '3']).item === 'coal' && r.parse('inv.take', ['coal', '3']).count === 3, 'take: CLI posisional item count')

  // ================= engine.state =================
  b = mkInv({ inv: { 36: ['cobblestone', 37] } }); b.put(20, 'unknown', 2, 6666); r = createRunner(b); const eng = createEngine(b, r)
  let st = eng.state()
  ok(st.inventory.source === 'protocol' && st.inventory.accurate === false && st.inventory.items.some(i => i.name === 'unknown#6666'), 'state: tanpa snapshot -> protocol, accurate=false, unknown#id')
  b.srv.invOverride = { 20: 'touhou_little_maid:bell' }; await r.run('inv.snapshot', {})
  st = eng.state()
  ok(st.inventory.source === 'snbt' && st.inventory.accurate === true && st.inventory.items.some(i => i.name === 'touhou_little_maid:bell'), 'state: snapshot cocok & segar -> snbt, accurate=true, nama modded terbaca')
  b.arcadia.inventoryTruth.ts = Date.now() - 31000; st = eng.state()
  ok(st.inventory.source === 'protocol' && st.inventory.accurate === false, 'state: snapshot kedaluwarsa (>30 dtk) -> kembali protocol/accurate=false')
  b.arcadia.inventoryTruth.ts = Date.now(); b.arcadia.inventoryTruth.accurate = false; st = eng.state()
  ok(st.inventory.accurate === false, 'state: snapshot tidak cocok -> accurate=false')
  const { validate } = require('../contracts/validate'); b.arcadia.inventoryTruth.accurate = true
  ok(validate('BotState', eng.state()) === null || validate('BotState', eng.state()) === undefined || !validate('BotState', eng.state()), 'state: tetap valid terhadap kontrak BotState')

  fs.rmSync(TMP, { recursive: true, force: true })
  console.log('\nHASIL: ' + pass + ' lulus, ' + fail + ' gagal')
  process.exit(fail ? 1 : 0)
})().catch(e => { console.log('EXCEPTION', e); process.exit(1) })
