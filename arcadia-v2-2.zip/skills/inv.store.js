const U = require('./_util')
const I = require('./_inv')

const manifest = {
  name: 'inv.store',
  description: 'Pindahkan item inventory ke chest/barrel (default: semua item vanilla kecuali alat/senjata), lalu laporkan isi chest. Item modded dilewati kecuali includeModded=true',
  paramsSchema: {
    type: 'object',
    properties: {
      chest: { type: ['boolean', 'string', 'object'], description: 'true/"auto" = terdekat; {x,y,z} atau "x y z"' },
      items: { type: ['string', 'array'], description: '"all" (default) atau daftar nama dipisah koma, mis. "cobblestone,dirt"' },
      keep: { type: ['string', 'array'], description: 'nama item yang JANGAN dipindah (berlaku untuk items=all)' },
      keepTools: { type: 'boolean', default: true, description: 'items=all: jangan pindahkan pickaxe/axe/sword/shovel/hoe/bow/shield/dll' },
      includeModded: { type: 'boolean', default: false, description: 'ikutkan item modded (serialisasi komponen belum terbukti; bisa ditolak server)' },
      verify: { type: 'boolean', default: true, description: 'cek isi chest ke server lewat /data get block bila bot op' },
      waitMs: { type: 'integer', minimum: 1000, maximum: 20000, default: 6000 }
    }
  },
  requires: ['move', 'block.read', 'inventory.protocol', 'chat'],
  interruptible: true,
  estimatedMs: 20000
}

// jumlah per jenis di slot inventory utama + hotbar (9-44); armor/tangan kiri/crafting tak disentuh
function mainStacks (bot) {
  const m = new Map()
  for (let s = 9; s <= 44; s++) {
    const it = bot.inventory.slots[s]; if (!it || it.count <= 0) continue
    const e = m.get(it.type) || { type: it.type, item: it, key: U.itemKey(it), id: I.fullId(it), count: 0 }
    e.count += it.count; m.set(it.type, e)
  }
  return [...m.values()]
}

async function run (bot, p, ctx) {
  const want = I.toList(p.items); const all = !want.length || want.includes('all')
  const keep = new Set(I.toList(p.keep))
  const keepTools = p.keepTools !== false
  const includeModded = p.includeModded === true

  const before = mainStacks(bot)
  const plan = []; const skipped = []
  for (const e of before) {
    const modded = e.key.startsWith('unknown#') || I.isModdedId(e.id) || e.item.name === 'unknown'
    if (modded && !includeModded) { skipped.push({ item: e.key, count: e.count, why: 'modded' }); continue }
    if (!all && !want.includes(e.key) && !want.includes(e.id)) continue
    if (keep.has(e.key) || keep.has(e.id)) { skipped.push({ item: e.key, count: e.count, why: 'keep' }); continue }
    if (all && keepTools && I.isKeepTool(e.key)) { skipped.push({ item: e.key, count: e.count, why: 'alat' }); continue }
    plan.push(e)
  }
  if (!all) for (const n of want) if (!before.some(e => e.key === n || e.id === n)) skipped.push({ item: n, count: 0, why: 'tidak ada di inventory' })
  if (!plan.length) return { ok: false, code: 'PRECONDITION_FAILED', error: 'tidak ada item yang bisa dipindah', data: { skipped } }

  const o = await I.openChest(bot, ctx, p.chest)
  if (!o.ok) return { ok: false, code: o.code, error: o.error, data: { skipped, ...(o.chest ? { chest: o.chest } : {}) } }
  const w = o.w
  const moved = {}; const failed = []; let chestFull = false
  try {
    const slotsBefore = I.windowItems(w)
    for (const e of plan) {
      if (ctx.signal.aborted) break
      const had = mainStacks(bot).find(x => x.type === e.type); const b4 = had ? had.count : 0
      try { await w.deposit(e.type, null, e.count) } catch (err) {
        failed.push({ item: e.key, error: String(err.message).slice(0, 100) })
        if (/full/i.test(err.message)) { chestFull = true; break }
      }
      await U.sleep(150)
      const now = mainStacks(bot).find(x => x.type === e.type); const n = b4 - (now ? now.count : 0)
      if (n > 0) moved[e.key] = n
      if (n < e.count && !failed.some(f => f.item === e.key)) failed.push({ item: e.key, error: 'hanya ' + n + '/' + e.count + ' terpindah (chest penuh atau ditolak server)' })
    }
    await U.sleep(300)
    const after = I.windowItems(w)
    const total = Object.values(moved).reduce((a, n) => a + n, 0)
    const slots = I.chestSlots(w)
    const data = { chest: o.info, moved, movedTotal: total, skipped, failed, chestFull, chestAfter: { slots, free: slots - after.length, totals: I.totalsOf(after), items: after.length, itemsBefore: slotsBefore.length } }

    if (p.verify === false) data.verify = { checked: false, reason: 'verify=false' }
    else if (I.isDouble(o.block)) data.verify = { checked: false, reason: 'chest ganda' }
    else {
      const sv = await I.serverChest(bot, o.block.position, { timeoutMs: p.waitMs || 6000, signal: ctx.signal })
      if (!sv.ok) data.verify = { checked: false, reason: sv.error, code: sv.code }
      else { const d = I.diffSlots(after, sv.items); data.verify = { checked: true, ok: I.accurate(d), serverTotals: I.totalsOf(sv.items), missingInWindow: d.missing.slice(0, 20), diff: d.idDiff.concat(d.countDiff).slice(0, 20) } }
    }
    if (total <= 0) return { ok: false, code: chestFull ? 'PRECONDITION_FAILED' : 'SERVER_REJECTED', error: chestFull ? 'chest penuh' : 'tidak ada item yang terpindah', data }
    return { ok: true, code: 'OK', data }
  } finally { try { w.close() } catch (e) { /* abaikan */ } }
}

module.exports = { manifest, run, cli: [] }
