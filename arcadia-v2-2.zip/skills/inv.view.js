const U = require('./_util')
const I = require('./_inv')

const manifest = {
  name: 'inv.view',
  description: 'Buka chest/barrel dan daftar isinya; verify=true membandingkan dengan /data get block (butuh bot op) untuk mendeteksi item yang tak terbaca bot',
  paramsSchema: {
    type: 'object',
    properties: {
      chest: { type: ['boolean', 'string', 'object'], description: 'true/"auto" = terdekat; {x,y,z} atau "x y z" = di/dekat koordinat itu' },
      verify: { type: 'boolean', default: true },
      waitMs: { type: 'integer', minimum: 1000, maximum: 20000, default: 6000 }
    }
  },
  requires: ['move', 'block.read', 'inventory.protocol', 'chat'],
  interruptible: true,
  estimatedMs: 15000
}

async function run (bot, p, ctx) {
  const o = await I.openChest(bot, ctx, p.chest)
  if (!o.ok) return { ok: false, code: o.code, error: o.error, data: o.chest ? { chest: o.chest } : undefined }
  const w = o.w
  try {
    await U.sleep(250)
    const items = I.windowItems(w)
    const slots = I.chestSlots(w)
    const data = { chest: o.info, slots, used: items.length, free: slots - items.length, items: items.map(i => ({ slot: i.slot, id: i.id, count: i.count })), totals: I.totalsOf(items) }
    if (p.verify === false) data.verify = { checked: false, reason: 'verify=false' }
    else if (I.isDouble(o.block)) data.verify = { checked: false, reason: 'chest ganda: /data get block hanya membaca setengah' }
    else {
      const sv = await I.serverChest(bot, o.block.position, { timeoutMs: p.waitMs || 6000, signal: ctx.signal })
      if (!sv.ok) data.verify = { checked: false, reason: sv.error, code: sv.code }
      else {
        const d = I.diffSlots(items, sv.items)
        data.verify = { checked: true, ok: I.accurate(d), serverItems: sv.items.length, missingInWindow: d.missing.slice(0, 20), extraInWindow: d.extra.slice(0, 20), diff: d.idDiff.concat(d.countDiff).slice(0, 20) }
        if (!data.verify.ok) data.note = 'jendela chest di bot berbeda dari server (kemungkinan item bermuatan komponen modded tak terbaca): ' + d.missing.length + ' hilang di jendela'
      }
    }
    return { ok: true, code: 'OK', data }
  } finally { try { w.close() } catch (e) { /* abaikan */ } }
}

module.exports = { manifest, run, cli: [] }
