const U = require('./_util')
const I = require('./_inv')
const names = require('./_names')

const manifest = {
  name: 'inv.take',
  description: 'Ambil item dari chest/barrel ke inventory bot (nama item vanilla; modded hanya dengan includeModded=true)',
  paramsSchema: {
    type: 'object',
    required: ['item'],
    properties: {
      item: { type: ['string', 'array'], description: 'nama item, boleh beberapa dipisah koma, mis. "iron_ingot,coal"' },
      count: { type: ['integer', 'string'], description: 'jumlah per item, atau "all" (default 64)' },
      chest: { type: ['boolean', 'string', 'object'], description: 'true/"auto" = terdekat; {x,y,z} atau "x y z"' },
      includeModded: { type: 'boolean', default: false },
      verify: { type: 'boolean', default: true },
      waitMs: { type: 'integer', minimum: 1000, maximum: 20000, default: 6000 }
    }
  },
  requires: ['move', 'block.read', 'inventory.protocol', 'chat'],
  interruptible: true,
  estimatedMs: 20000
}

const totalsMain = bot => { const m = {}; for (let s = 9; s <= 44; s++) { const it = bot.inventory.slots[s]; if (it && it.count > 0) { const k = U.itemKey(it); m[k] = (m[k] || 0) + it.count } } return m }

async function run (bot, p, ctx) {
  const want = I.toList(p.item)
  if (!want.length) return { ok: false, code: 'PRECONDITION_FAILED', error: 'param item kosong' }
  const countAll = p.count === 'all'
  const count = countAll ? Infinity : Math.max(1, parseInt(p.count ?? 64, 10) || 64)
  const md = ctx.mcData

  // nama -> id numerik (vanilla dari mcData; modded lewat registri bila diizinkan)
  const targets = []; const unknown = []
  for (const n of want) {
    const short = n.replace(/^minecraft:/, '')
    const v = md.itemsByName[short]
    if (v) { targets.push({ name: short, type: v.id }); continue }
    if (p.includeModded === true) { const id = names.idOf(n); if (id !== undefined) { targets.push({ name: n, type: id }); continue } }
    unknown.push(n)
  }
  if (!targets.length) return { ok: false, code: 'PRECONDITION_FAILED', error: 'item tidak dikenal/modded tanpa includeModded: ' + unknown.join(','), data: { unknown } }

  const o = await I.openChest(bot, ctx, p.chest)
  if (!o.ok) return { ok: false, code: o.code, error: o.error, data: o.chest ? { chest: o.chest } : undefined }
  const w = o.w
  try {
    await U.sleep(250)
    const b4 = totalsMain(bot)
    const items0 = I.windowItems(w)
    const moved = {}; const missing = []; const failed = []; let invFull = false
    for (const t of targets) {
      if (ctx.signal.aborted) break
      const avail = items0.filter(i => i.type === t.type).reduce((a, i) => a + i.count, 0)
      if (!avail) { missing.push(t.name); continue }
      const n = Math.min(count, avail)
      try { await w.withdraw(t.type, null, n) } catch (err) {
        failed.push({ item: t.name, error: String(err.message).slice(0, 100) })
        if (/full/i.test(err.message)) { invFull = true; break }
      }
      await U.sleep(150)
    }
    await U.sleep(300)
    const a4 = totalsMain(bot)
    for (const t of targets) { const k = t.name; const n = (a4[k] || 0) - (b4[k] || 0); if (n > 0) moved[k] = n }
    const after = I.windowItems(w)
    const slots = I.chestSlots(w)
    const total = Object.values(moved).reduce((a, n) => a + n, 0)
    const data = { chest: o.info, moved, movedTotal: total, missing, unknown, failed, inventoryFull: invFull, chestAfter: { slots, free: slots - after.length, totals: I.totalsOf(after) } }
    if (p.verify === false) data.verify = { checked: false, reason: 'verify=false' }
    else if (I.isDouble(o.block)) data.verify = { checked: false, reason: 'chest ganda' }
    else {
      const sv = await I.serverChest(bot, o.block.position, { timeoutMs: p.waitMs || 6000, signal: ctx.signal })
      if (!sv.ok) data.verify = { checked: false, reason: sv.error, code: sv.code }
      else { const d = I.diffSlots(after, sv.items); data.verify = { checked: true, ok: I.accurate(d), serverTotals: I.totalsOf(sv.items), missingInWindow: d.missing.slice(0, 20), diff: d.idDiff.concat(d.countDiff).slice(0, 20) } }
    }
    if (total > 0) return { ok: true, code: 'OK', data }
    if (invFull) return { ok: false, code: 'INVENTORY_FULL', error: 'inventory bot penuh', data }
    if (missing.length) return { ok: false, code: 'TARGET_NOT_FOUND', error: 'tidak ada di chest: ' + missing.join(',') + '; isi chest: ' + Object.entries(I.totalsOf(items0)).slice(0, 15).map(([k, v]) => k.replace('minecraft:', '') + ' x' + v).join(', '), data }
    return { ok: false, code: 'SERVER_REJECTED', error: 'tidak ada item yang terambil', data }
  } finally { try { w.close() } catch (e) { /* abaikan */ } }
}

module.exports = { manifest, run, cli: ['item', 'count'] }
