// Pemasangan paket v2.2 (inventory): edit file lama dengan anchor (aman diulang) + catatan dokumen.
// File baru (skills/_snbt.js, _names.js, _inv.js, inv.*.js, tests/inv.test.js) datang dari zip.
const fs = require('fs')
let failed = 0
function edit (file, anchor, replacement, done) {
  if (!fs.existsSync(file)) { console.log(file + ': TIDAK ADA'); failed++; return }
  const s = fs.readFileSync(file, 'utf8')
  if (s.includes(done)) return console.log(file + ': sudah ter-fix')
  if (!s.includes(anchor)) { console.log(file + ': ANCHOR TIDAK DITEMUKAN (file berbeda dari yang diuji); tidak diubah'); failed++; return }
  fs.writeFileSync(file, s.replace(anchor, replacement))
  console.log(file + ': diperbarui')
}
function append (file, marker, text) {
  if (!fs.existsSync(file)) return console.log(file + ': tidak ada, dilewati')
  const s = fs.readFileSync(file, 'utf8')
  if (s.includes(marker)) return console.log(file + ': sudah ter-update')
  fs.writeFileSync(file, s.replace(/\n*$/, '\n') + text)
  console.log(file + ': diperbarui')
}

edit('skills/_util.js',
  "const itemKey = i => i.name === 'unknown' || !i.name ? 'unknown#' + i.type : i.name",
  "// nama item modded: dari registri sinkronisasi / hasil snapshot bila ada ('ns:path'), kalau tidak 'unknown#<id>'\nconst itemKey = i => { if (i.name && i.name !== 'unknown') return i.name; const n = require('./_names').nameOf(i.type); return n || 'unknown#' + i.type }",
  "require('./_names').nameOf(i.type)")

edit('engine/index.js',
  "    if (bot.inventory) st.inventory = { items: bot.inventory.items().map(i => ({ name: i.name === 'unknown' || !i.name ? 'unknown#' + i.type : i.name, count: i.count, slot: i.slot })), source: 'protocol', accurate: false }",
  "    if (bot.inventory) {\n      const T = bot.arcadia && bot.arcadia.inventoryTruth\n      const fresh = !!(T && T.accurate && Date.now() - T.ts < 30000) // snapshot cocok dan masih segar (<30 dtk)\n      st.inventory = { items: bot.inventory.items().map(i => ({ name: require('../skills/_util').itemKey(i), count: i.count, slot: i.slot })), source: fresh ? 'snbt' : 'protocol', accurate: fresh }\n    }",
  'inventoryTruth')

edit('bot.js',
  "const showChannels = require('./sniff')(client)",
  "// nama item modded dari registri sinkronisasi (unknown#<id> -> ns:path)\nclient.on('neoforgeRegistry', r => { if (r.name === 'minecraft:item') console.log('ITEM NAMES: ' + require('./skills/_names').load(r.ids) + ' id dimuat dari registri sinkronisasi') })\n\nconst showChannels = require('./sniff')(client)",
  'ITEM NAMES')

edit('package.json',
  '"test": "node tests/skills.test.js && node tests/engine.test.js"',
  '"test": "node tests/skills.test.js && node tests/engine.test.js && node tests/inv.test.js"',
  'tests/inv.test.js')

edit('tests/engine.test.js',
  "ok(sk.length === 5 && sk.every(s => !validate('SkillManifest', s)), '/skills: 5 manifest valid kontrak')",
  "ok(sk.length === 9 && ['inv.snapshot', 'inv.view', 'inv.store', 'inv.take'].every(n => sk.some(s => s.name === n)) && sk.every(s => !validate('SkillManifest', s)), '/skills: 9 manifest valid kontrak (termasuk 4 skill inv.*)')",
  "9 manifest valid kontrak")

// .gitignore: berkas snapshot lokal
if (fs.existsSync('.gitignore')) {
  let g = fs.readFileSync('.gitignore', 'utf8')
  const add = ['snapshot.json', 'snapshot_raw.txt'].filter(l => !g.split(/\r?\n/).includes(l))
  if (add.length) { fs.writeFileSync('.gitignore', g.replace(/\n*$/, '\n') + add.join('\n') + '\n'); console.log('.gitignore: +' + add.join(', ')) } else console.log('.gitignore: sudah ter-fix')
}

append('TODO.md', '## Pembaruan #7', `## Pembaruan #7 (inventory)
- [~] inv.snapshot: bandingkan bot.inventory dengan /data get entity <bot> Inventory (butuh op); belajar nama item modded; state.inventory jadi source=snbt/accurate=true bila snapshot cocok dan <30 dtk - TERUJI TIRUAN, BELUM DIUJI di server
- [~] inv.view / inv.store / inv.take: lihat, simpan, ambil dari chest dengan verifikasi /data get block Items; item modded dilewati kecuali includeModded - TERUJI TIRUAN, BELUM DIUJI di server
- [~] Nama item modded dari registri minecraft:item (log "ITEM NAMES: n id"); bila tidak muncul, nama dipelajari dari inv.snapshot (itemmap.json)
- [ ] Format keluaran /data get di server asli belum pernah dilihat: bila PROTOCOL_UNSUPPORTED, kirim snapshot_raw.txt
- [ ] View 3D (prismarine-viewer) untuk UI - BELUM dikerjakan, lihat catatan kelayakan
`)
append('docs/HANDOFF.md', '## 13. Pembaruan checkpoint #7', `## 13. Pembaruan checkpoint #7
- Skill baru: inv.snapshot, inv.view, inv.store, inv.take (+ pembantu skills/_snbt.js, _names.js, _inv.js; tes tests/inv.test.js, 58 kasus). Semuanya TERUJI TIRUAN, BELUM DIUJI di server.
- Kebenaran inventory/chest = /data get ... (bot harus op, gamerule sendCommandFeedback true). Jendela chest dan inventory protokol bisa tertinggal karena paket bermuatan komponen modded gagal parse.
- BotState.inventory: source=snbt, accurate=true hanya bila snapshot terakhir cocok dan berumur <30 dtk; selain itu protocol/false.
- Item modded: nama dari registri sinkronisasi (ITEM NAMES di log) atau hasil snapshot (itemmap.json). inv.store/inv.take melewati item modded kecuali includeModded=true (serialisasi komponen item belum terbukti).
`)
console.log(failed ? '\n' + failed + ' MASALAH: lihat pesan di atas' : '\nSELESAI. Jalankan: npm test && npm run check')
process.exit(failed ? 1 : 0)
