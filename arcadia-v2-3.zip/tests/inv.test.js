// tests/inv.test.js - SNBT, nama item, inv.snapshot / inv.view / inv.store / inv.take (bot tiruan, tanpa server)
const fs = require('fs'); const os = require('os'); const path = require('path')
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'arcadia-inv-'))
process.env.ARCADIA_DATA_DIR = TMP // sebelum modul lain dimuat: itemmap.json/snapshot*.json masuk folder sementara
const { mk, mkBlock, mcData, it } = require('./mock')
const snbt = require('../skills/_snbt')
const names = require('../skills/_names')
const U = require('../skills/_util')
const { createRunner } = require('../skills')
const { createEngine } = require('../engine')
let pass = 0; let fail = 0
const ok = (c, m) => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + m) }
const sleep = ms => new Promise(r => setTimeout(r, ms))

// ---------- tiruan server: teks /data get ... ----------
const { EventEmitter } = require('events')
const mcToNbt = s => s >= 36 && s <= 44 ? s - 36 : s >= 9 && s <= 35 ? s : s >= 5 && s <= 8 ? 103 - (s - 5) : s === 45 ? -106 : null
const compsTxt = c => c && Object.keys(c).length ? ', components: {' + Object.entries(c).map(([k, v]) => '"' + k + '": ' + (typeof v === 'string' ? '"' + v + '"' : JSON.stringify(v))).join(', ') + '}' : ''
const itemTxt = (slotTxt, e) => '{Slot: ' + slotTxt + ', id: "' + e.id + '", count: ' + e.count + compsTxt(e.comps) + '}'

// Model server tunggal (kebenaran): srvInv/srvChest. Tampilan bot (slots, window) hanya berisi item yang TERBACA;
// item 'hidden*' hanya ada di server (mis. paket bermuatan komponen modded dibuang bot).
function mkInv (o = {}) {
  const b = mk({ blocks: o.blocks || [mkBlock('chest', 3, 64, 0)], ...(o.mk || {}) })
  b.username = 'BotAlpha'
  b._client = new EventEmitter(); b.writes = []; b._closedIds = []; b._closed = 0
  const slots = new Array(46).fill(null)
  const srvInv = new Array(46).fill(null)
  const srvChest = new Array(27).fill(null)
  const view = new Array(27).fill(null) // isi chest di jendela bot (mode normal)
  b.inventory = { slots, items: () => slots.filter(i => i && i.count > 0), count: type => slots.filter(i => i && i.type === type).reduce((a, i) => a + i.count, 0), updateSlot: (s, item) => { slots[s] = item } }
  const idOf = n => (it(n) ? it(n).id : null)
  const plain = e => e.id.startsWith('minecraft:') && !(e.comps && Object.keys(e.comps).length)
  const later = fn => (o.lagMs ? setTimeout(fn, o.lagMs) : fn())
  b.put = (slot, name, count, type, srvId) => {
    const known = idOf(name)
    slots[slot] = { type: known != null ? known : type, name: known != null ? name : 'unknown', count, slot }
    srvInv[slot] = { id: srvId || (known != null ? 'minecraft:' + name : 'mod:unknown'), count, comps: {} }
  }
  for (const [slot, [name, count, type, srvId]] of Object.entries(o.inv || {})) b.put(Number(slot), name, count, type, srvId)
  for (const h of o.hiddenInv || []) srvInv[h.slot] = { id: h.id, count: h.count, comps: h.comps || {} }
  for (const [slot, [name, count]] of Object.entries(o.chest || {})) { const e = { id: 'minecraft:' + name, count, comps: {} }; srvChest[Number(slot)] = e; view[Number(slot)] = { type: idOf(name), name, count, slot: Number(slot) } }
  for (const h of o.hiddenChest || []) srvChest[h.slot] = { id: h.id, count: h.count, comps: h.comps || {} }
  b._srvChest = srvChest; b._srvInv = srvInv; b._view = view
  b.srv = { noOp: !!o.noOp, silent: !!o.silent, garbage: !!o.garbage }
  const say = t => setTimeout(() => b.emit('messagestr', t, 'system', {}), 5)
  b.chat = text => {
    b.sent = (b.sent || []).concat(text)
    if (b.srv.silent) return
    if (b.srv.noOp && text.startsWith('/data')) return say('Unknown or incomplete command, see below for error')
    if (/^\/data get entity BotAlpha Inventory/.test(text)) {
      if (b.srv.garbage) return say('BotAlpha has the following entity data: [{Slot: 0b, id: "minecraft:st')
      const truth = []
      srvInv.forEach((e, s) => { if (e && e.count > 0 && mcToNbt(s) != null) truth.push({ s: mcToNbt(s), ...e }) })
      if (!truth.length) return say('Found no elements matching Inventory')
      return say('BotAlpha has the following entity data: [' + truth.map(e => itemTxt(e.s + 'b', e)).join(', ') + ']')
    }
    const m = /^\/data get block (-?\d+) (-?\d+) (-?\d+) Items/.exec(text)
    if (m) {
      const items = []; srvChest.forEach((e, s) => { if (e && e.count > 0) items.push({ s, ...e }) })
      if (!items.length) return say('Found no elements matching Items')
      return say(m[1] + ', ' + m[2] + ', ' + m[3] + ' has the following block data: [' + items.map(e => itemTxt(e.s + 'b', e)).join(', ') + ']')
    }
  }
  const sameId = (x, y) => x && y && x.id === y.id && JSON.stringify(x.comps || {}) === JSON.stringify(y.comps || {})
  const toChest = (item) => { // gabung ke stack sama atau slot kosong; -> indeks atau -1
    let i = srvChest.findIndex(c => c && sameId(c, item) && c.count < 64); if (i >= 0) return i
    return srvChest.findIndex(c => !c)
  }
  const toInv = (item) => {
    for (let s = 9; s <= 44; s++) if (srvInv[s] && sameId(srvInv[s], item) && srvInv[s].count < 64) return s
    for (let s = 9; s <= 44; s++) if (!srvInv[s]) return s
    return -1
  }
  // pindah satu stack penuh (shift-click). dir: 'toChest' | 'toInv'
  const quick = (dir, slot) => {
    if (dir === 'toChest') {
      const e = srvInv[slot]; if (!e) return
      const ci = toChest(e); if (ci < 0) return
      const room = srvChest[ci] ? 64 - srvChest[ci].count : 64; const n = Math.min(e.count, room)
      if (!srvChest[ci]) srvChest[ci] = { id: e.id, count: 0, comps: e.comps }
      srvChest[ci].count += n; e.count -= n
      const bs = slots[slot]
      if (plain(srvChest[ci])) later(() => { view[ci] = view[ci] || { type: idOf(srvChest[ci].id.slice(10)), name: srvChest[ci].id.slice(10), count: 0, slot: ci }; view[ci].count = srvChest[ci].count; if (bs) { bs.count -= n; if (bs.count <= 0) slots[slot] = null } })
      if (e.count <= 0) srvInv[slot] = null
    } else {
      const e = srvChest[slot]; if (!e) return
      const di = toInv(e); if (di < 0) return
      const room = srvInv[di] ? 64 - srvInv[di].count : 64; const n = Math.min(e.count, room)
      if (!srvInv[di]) srvInv[di] = { id: e.id, count: 0, comps: e.comps }
      srvInv[di].count += n; e.count -= n
      if (plain(srvInv[di])) later(() => { slots[di] = slots[di] || { type: idOf(srvInv[di].id.slice(10)), name: srvInv[di].id.slice(10), count: 0, slot: di }; slots[di].count = srvInv[di].count; if (view[slot]) { view[slot].count = e.count; if (e.count <= 0) view[slot] = null } })
      if (e.count <= 0) srvChest[slot] = null
    }
  }
  b._client.write = (name, pkt) => {
    b.writes.push({ name, ...pkt })
    if (name === 'close_window') { b._closedIds.push(pkt.windowId); return }
    if (name === 'window_click' && pkt.mode === 1 && !o.ignoreClicks) { if (pkt.slot < 27) quick('toInv', pkt.slot); else quick('toChest', pkt.slot - 27 + 9) }
  }
  const win = {
    id: 7, inventoryStart: 27,
    containerItems: () => view.filter(Boolean).map(c => ({ ...c })),
    close () { b._closed++; b.currentWindow = null },
    deposit: async (type, meta, n) => {
      let left = n; let moved = 0
      for (let s = 9; s <= 44 && left > 0; s++) {
        const x = slots[s]; if (!x || x.type !== type || !srvInv[s]) continue
        const ci = toChest(srvInv[s]); if (ci < 0) break
        const room = srvChest[ci] ? 64 - srvChest[ci].count : 64; const take = Math.min(left, x.count, room)
        if (!srvChest[ci]) srvChest[ci] = { id: srvInv[s].id, count: 0, comps: srvInv[s].comps }
        srvChest[ci].count += take; srvInv[s].count -= take; if (srvInv[s].count <= 0) srvInv[s] = null
        later(() => { view[ci] = view[ci] || { type, name: x.name, count: 0, slot: ci }; view[ci].count = srvChest[ci] ? srvChest[ci].count : view[ci].count; x.count -= take; if (x.count <= 0) slots[s] = null })
        left -= take; moved += take
      }
      if (!moved) throw new Error('destination full')
    },
    withdraw: async (type, meta, n) => {
      let left = n; let moved = 0
      for (let c = 0; c < 27 && left > 0; c++) {
        const v = view[c]; const e = srvChest[c]; if (!v || v.type !== type || !e) continue
        const di = toInv(e); if (di < 0) break
        const room = srvInv[di] ? 64 - srvInv[di].count : 64; const take = Math.min(left, e.count, room)
        if (!srvInv[di]) srvInv[di] = { id: e.id, count: 0, comps: e.comps }
        srvInv[di].count += take; e.count -= take
        later(() => { slots[di] = slots[di] || { type, name: v.name, count: 0, slot: di }; slots[di].count = srvInv[di].count; v.count = e.count; if (e.count <= 0) { view[c] = null } })
        if (e.count <= 0) srvChest[c] = null
        left -= take; moved += take
      }
      if (!moved) throw new Error('destination full')
    }
  }
  b.activateBlock = async () => {
    b.activations = (b.activations || 0) + 1
    setTimeout(() => {
      if (o.noOpen) return
      if (o.degradedOpen) { b.currentWindow = { id: 7, inventoryStart: 27, slots: [] }; b._client.emit('open_window', { windowId: 7 }); return }
      b.currentWindow = win; b._client.emit('open_window', { windowId: 7 }); b.emit('windowOpen', win)
    }, 20)
  }
  return b
}
const inv = (b, name) => b.inventory.slots.filter(i => i && (i.name === name)).reduce((a, i) => a + i.count, 0)
const srvInvCount = (b, id) => b._srvInv.filter(e => e && e.id === id).reduce((a, e) => a + e.count, 0)
const chestCount = (b, name) => b._srvChest.filter(e => e && e.id === 'minecraft:' + name).reduce((a, e) => a + e.count, 0)
const chestIdCount = (b, id) => b._srvChest.filter(e => e && e.id === id).reduce((a, e) => a + e.count, 0)

process.env.ARCADIA_OPEN_MS = '600'; process.env.ARCADIA_OPEN_GRACE_MS = '400' // percepat uji jendela yang tak terbuka/degraded
;(async () => {
  let b, r, o

  // ================= SNBT =================
  let v = snbt.extract('BotAlpha has the following entity data: [{Slot: 0b, id: "minecraft:iron_pickaxe", count: 1, components: {"minecraft:damage": 12, "minecraft:enchantments": {levels: {"minecraft:efficiency": 3}}}}, {Slot: -106b, id: "minecraft:shield", count: 1}]')
  let items = snbt.inventoryItems(v)
  ok(items.length === 2 && items[0].slot === 36 && items[0].id === 'minecraft:iron_pickaxe' && items[0].comps.join() === 'minecraft:damage,minecraft:enchantments' && items[1].slot === 45, 'SNBT: inventory 1.21 (count/id/components, slot hotbar 0b -> 36, tangan kiri -106b -> 45)')
  v = snbt.parse('{a: [I; -1, 2, 3], b: 1.5f, c: 2.0d, d: 5L, e: true, f: "x\\"y", g: \'it\\\'s\', h: [B; 1b, 2b], i: 9007199254740993L, j: -7s, k: 1e3, l: minecraft:stone}')
  ok(v.a.join() === '-1,2,3' && v.b === 1.5 && v.c === 2 && v.d === 5 && v.e === true && v.f === 'x"y' && v.g === "it's" && v.h.join() === '1,2' && v.i === '9007199254740993' && v.j === -7 && v.k === 1000 && v.l === 'minecraft:stone', 'SNBT: tipe angka, array bertipe, boolean, escape, long tak aman jadi string, token tanpa kutip')
  v = snbt.parse('[\n  { Slot : 1b ,\n    id : "minecraft:dirt" , count : 4 , } ,\n]')
  ok(Array.isArray(v) && v.length === 1 && v[0].Slot === 1 && v[0].count === 4, 'SNBT: toleran spasi, baris baru, koma penutup')
  let threw = false; try { snbt.extract('x has the following entity data: [{Slot: 0b, id: "minec') } catch (e) { threw = /SNBT/.test(e.message) }
  ok(threw, 'SNBT: data terpotong -> error jelas')
  threw = false; try { snbt.extract('tidak ada data') } catch (e) { threw = true }
  ok(threw, 'SNBT: teks tanpa [ atau { -> error')
  ok([[0, 36], [8, 44], [9, 9], [35, 35], [100, 8], [101, 7], [102, 6], [103, 5], [-106, 45]].every(([n, s]) => snbt.nbtSlotToMc(n) === s) && snbt.nbtSlotToMc(50) === null, 'slot NBT -> slot jendela (hotbar, utama, armor, tangan kiri)')
  threw = false; try { snbt.parse('{a:'.repeat(70) + '1' + '}'.repeat(70)) } catch (e) { threw = /dalam/.test(e.message) }
  ok(threw, 'SNBT: kedalaman berlebih ditolak')

  // ================= nama item =================
  names.load([{ key: 'touhou_little_maid:bell', value: 9999 }])
  ok(U.itemKey({ name: 'unknown', type: 9999 }) === 'touhou_little_maid:bell' && U.itemKey({ name: 'unknown', type: 8888 }) === 'unknown#8888' && U.itemKey({ name: 'bread', type: 1 }) === 'bread', 'itemKey: nama dari registri sinkronisasi, cadangan unknown#id, vanilla tetap')
  names.load([])

  // ================= inv.snapshot =================
  b = mkInv({ inv: { 36: ['cobblestone', 37], 37: ['iron_pickaxe', 1], 12: ['coal', 5] } }); r = createRunner(b)
  ok(['inv.snapshot', 'inv.view', 'inv.store', 'inv.take'].every(n => r.skills[n]), 'runner memuat 4 skill inventory')
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.accurate && o.data.matched === 3 && o.data.serverItems === 3 && b.arcadia.inventoryTruth.matched, 'snapshot: inventory cocok -> accurate=true (3 item)')
  ok(fs.existsSync(path.join(TMP, 'snapshot.json')) && JSON.parse(fs.readFileSync(path.join(TMP, 'snapshot.json'), 'utf8')).accurate === true, 'snapshot: snapshot.json ditulis')
  ok(b.sent[0] === '/data get entity BotAlpha Inventory', 'snapshot: perintah yang dikirim benar')

  b = mkInv({ inv: { 36: ['cobblestone', 37] }, hiddenInv: [{ slot: 41, id: 'sophisticatedbackpacks:backpack', count: 1, comps: { 'sophisticatedbackpacks:storage_contents': 'x' } }] }); r = createRunner(b)
  o = await r.run('inv.snapshot', {})
  ok(o.ok && !o.data.accurate && o.data.missingInBot.length === 1 && o.data.missingInBot[0].modded === true && o.data.missingInBot[0].id === 'sophisticatedbackpacks:backpack' && /hilang di bot/.test(o.data.note) && b.arcadia.inventoryTruth.matched === false, 'snapshot: item modded bermuatan komponen tak terbaca bot terdeteksi (missingInBot, modded=true)')
  ok(o.data.unreadable.length === 1 && o.data.hydrated.length === 0 && o.data.moddedOrComponent[0].comps[0] === 'sophisticatedbackpacks:storage_contents', 'snapshot: item bermuatan komponen tidak dihidrasi (unreadable) dan nama komponennya dilaporkan')

  b = mkInv({ hiddenInv: [{ slot: 36, id: 'minecraft:dirt', count: 3 }, { slot: 14, id: 'minecraft:cobblestone', count: 64 }] }); r = createRunner(b)
  o = await r.run('inv.snapshot', { hydrate: false })
  ok(o.ok && o.data.protocolEmpty === true && !o.data.accurate && o.data.hydrated.length === 0, 'snapshot: hydrate=false, inventory bot kosong padahal server berisi -> protocolEmpty')
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.hydrated.length === 2 && o.data.accurate && inv(b, 'dirt') === 3 && inv(b, 'cobblestone') === 64 && /dipulihkan/.test(o.data.hydratedNote), 'snapshot: item polos yang sudah dibawa sebelum spawn dipulihkan ke tampilan bot (hidrasi) -> accurate=true')
  names.load([{ key: 'mod:thing', value: 5555 }])
  b = mkInv({ hiddenInv: [{ slot: 20, id: 'mod:thing', count: 4 }] }); r = createRunner(b); o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.hydrated.length === 1 && o.data.accurate && b.inventory.slots[20].type === 5555, 'snapshot: item modded polos dihidrasi memakai id dari registri sinkronisasi')
  names.load([])

  b = mkInv({ inv: { 36: ['cobblestone', 40] } }); r = createRunner(b)
  b._srvInv[36].count = 37 // server: 37, bot mengira 40
  o = await r.run('inv.snapshot', {})
  ok(o.ok && !o.data.accurate && o.data.countDiff.length === 1 && o.data.countDiff[0].bot === 40 && o.data.countDiff[0].server === 37, 'snapshot: selisih jumlah (bot 40, server 37) dilaporkan')

  b = mkInv({ inv: { 36: ['dirt', 2], 20: ['unknown', 2, 9999, 'touhou_little_maid:bell'] } }); r = createRunner(b)
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.learned['9999'] === 'touhou_little_maid:bell' && o.data.unknownNamed.length === 1, 'snapshot: unknown#9999 dipelajari sebagai touhou_little_maid:bell')
  ok(U.itemKey({ name: 'unknown', type: 9999 }) === 'touhou_little_maid:bell' && JSON.parse(fs.readFileSync(path.join(TMP, 'itemmap.json'), 'utf8'))['9999'] === 'touhou_little_maid:bell', 'snapshot: nama hasil belajar dipakai itemKey dan disimpan ke itemmap.json')
  o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.accurate && o.data.matched === 2 && o.data.unknownNamed.length === 0, 'snapshot ulang: id sudah dikenal -> cocok penuh (2 item)')

  b = mkInv({ noOp: true }); r = createRunner(b); o = await r.run('inv.snapshot', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /\/op BotAlpha/.test(o.error), 'snapshot: bot bukan op -> PRECONDITION_FAILED + petunjuk /op')
  b = mkInv({ silent: true }); r = createRunner(b); o = await r.run('inv.snapshot', { waitMs: 1000 })
  ok(!o.ok && o.code === 'TIMEOUT' && /sendCommandFeedback/.test(o.error), 'snapshot: tanpa balasan -> TIMEOUT (sebut gamerule)')
  b = mkInv({}); r = createRunner(b); o = await r.run('inv.snapshot', {})
  ok(o.ok && o.data.accurate && o.data.serverItems === 0, 'snapshot: inventory kosong ("Found no elements") -> OK, cocok')
  b = mkInv({ inv: { 36: ['dirt', 1] }, garbage: true }); r = createRunner(b); o = await r.run('inv.snapshot', {})
  ok(!o.ok && o.code === 'PROTOCOL_UNSUPPORTED' && fs.existsSync(path.join(TMP, 'snapshot_raw.txt')) && /minecraft:st/.test(fs.readFileSync(path.join(TMP, 'snapshot_raw.txt'), 'utf8')), 'snapshot: format tak terbaca -> PROTOCOL_UNSUPPORTED + teks mentah disimpan')

  // ================= inv.view =================
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12], 5: ['bread', 3] } }); r = createRunner(b)
  o = await r.run('inv.view', {})
  ok(o.ok && o.data.used === 3 && o.data.free === 24 && o.data.totals['minecraft:coal'] === 50 && o.data.verify.checked && o.data.verify.ok && b._closed === 1 && !o.data.degraded, 'view: 3 stack, 24 slot bebas, verifikasi server cocok, jendela ditutup')
  b = mkInv({ chest: { 0: ['coal', 50] }, hiddenChest: [{ slot: 3, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }] }); r = createRunner(b)
  o = await r.run('inv.view', {})
  ok(o.ok && o.data.verify.checked && !o.data.verify.ok && o.data.verify.missingInWindow.length === 1 && o.data.verify.missingInWindow[0].id === 'tacz:modern_kinetic_gun' && o.data.verify.missingInWindow[0].modded && /tak terbaca/.test(o.data.note), 'view: item modded yang hilang dari jendela terdeteksi lewat /data get block')
  b = mkInv({ chest: { 0: ['coal', 1] }, noOp: true }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(o.ok && o.data.verify.checked === false && /op/.test(o.data.verify.reason) && o.data.used === 1, 'view: tanpa op tetap menampilkan isi (verify dilewati dengan alasan)')
  b = mkInv({ chest: { 0: ['coal', 1] } }); r = createRunner(b); o = await r.run('inv.view', { verify: false })
  ok(o.ok && o.data.verify.checked === false && !(b.sent || []).length, 'view: verify=false tidak mengirim perintah')
  b = mkInv({ blocks: [] }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(!o.ok && o.code === 'TARGET_NOT_FOUND', 'view: tanpa chest -> TARGET_NOT_FOUND')
  const dbl = mkBlock('chest', 3, 64, 0); dbl.getProperties = () => ({ type: 'left' })
  b = mkInv({ blocks: [dbl], chest: { 0: ['coal', 1] } }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(o.ok && o.data.verify.checked === false && /ganda/.test(o.data.verify.reason), 'view: chest ganda -> verifikasi dilewati dengan alasan')
  b = mkInv({ chest: { 0: ['coal', 1] } }); r = createRunner(b); o = await r.run('inv.view', { chest: '3,64,0' })
  ok(o.ok && o.data.chest.how === 'koordinat', 'view: chest lewat koordinat teks "3,64,0"')

  // --- jendela tak terbaca (window_items dibuang): mode degraded ---
  b = mkInv({ chest: { 0: ['coal', 50] }, hiddenChest: [{ slot: 3, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }], degradedOpen: true }); r = createRunner(b)
  o = await r.run('inv.view', {})
  ok(o.ok && o.data.degraded && o.data.source === 'server' && o.data.used === 2 && o.data.totals['minecraft:coal'] === 50 && o.data.moddedOrComponent.length === 1 && o.data.moddedOrComponent[0].id === 'tacz:modern_kinetic_gun', 'view degraded: window_items tak terbaca -> isi chest diambil dari server (2 stack, 1 modded)')
  ok(b._closedIds.includes(7) && b.currentWindow === null, 'view degraded: jendela ditutup lewat close_window mentah (tidak menggantung)')
  b = mkInv({ chest: { 0: ['coal', 50] }, degradedOpen: true, noOp: true }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /tidak terbaca bot/.test(o.error) && b._closedIds.includes(7), 'view degraded tanpa op: gagal jelas dan jendela tetap ditutup')
  b = mkInv({ chest: { 0: ['coal', 5] }, noOpen: true }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(!o.ok && o.code === 'SERVER_REJECTED' && /tidak ada open_window/.test(o.error), 'view: server tidak membuka chest sama sekali -> SERVER_REJECTED yang jelas')
  b = mkInv({ chest: { 0: ['coal', 5] } }); let stale = false; b.currentWindow = { id: 3, close () { stale = true } }; r = createRunner(b); o = await r.run('inv.view', {})
  ok(o.ok && stale, 'view: jendela basi dari task sebelumnya ditutup sebelum membuka chest')
  b = mkInv({ chest: { 0: ['coal', 5] } }); b.currentWindow = { id: 9 }; b.emit('respawn'); r = createRunner(b); o = await r.run('inv.view', {})
  ok(o.ok && b.currentWindow === null, 'view: respawn/mati mereset jendela yang tertinggal')
  b = mkInv({ blocks: [mkBlock('chest', 30, 64, 0)], chest: {}, mk: { gotoErr: 'jalur buntu' } }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(!o.ok && (o.code === 'NO_PATH' || o.code === 'TIMEOUT') && /jarak \d+/.test(o.error), 'view: gagal menuju chest jauh -> NO_PATH dengan jarak dilaporkan')
  b = mkInv({ chest: { 0: ['coal', 1] } }); r = createRunner(b); o = await r.run('inv.view', {})
  ok(b._goals === undefined || b._goals.length === 0, 'view: chest dalam jangkauan -> pathfinder tidak dipanggil')

  // ================= inv.store =================
  const stash = () => ({ 9: ['cobblestone', 64], 10: ['cobblestone', 36], 11: ['dirt', 10], 12: ['iron_pickaxe', 1], 13: ['bread', 5], 14: ['unknown', 2, 9999, 'touhou_little_maid:bell'], 36: ['stone_sword', 1] })
  b = mkInv({ inv: stash() }); r = createRunner(b)
  o = await r.run('inv.store', {})
  ok(o.ok && o.data.moved.cobblestone === 100 && o.data.moved.dirt === 10 && o.data.moved.bread === 5 && o.data.movedTotal === 115 && o.data.movedBy === 'server', 'store: default memindahkan semua vanilla (cobblestone 100 dari 2 stack, dirt 10, bread 5), dihitung dari server')
  ok(inv(b, 'iron_pickaxe') === 1 && inv(b, 'stone_sword') === 1 && o.data.skipped.some(s => s.item === 'iron_pickaxe' && s.why === 'alat'), 'store: alat/senjata tetap di bot (keepTools)')
  ok(b.inventory.slots[14] && b.inventory.slots[14].count === 2 && o.data.skipped.some(s => s.why === 'modded' && s.item === 'touhou_little_maid:bell'), 'store: item modded dilewati secara default')
  ok(chestCount(b, 'cobblestone') === 100 && o.data.chestAfter.totals['minecraft:cobblestone'] === 100 && o.data.verify.checked && o.data.verify.ok && o.data.verify.serverTotals['minecraft:dirt'] === 10 && b._closed === 1, 'store: chest berisi sesuai, verifikasi server cocok, jendela ditutup')
  b = mkInv({ inv: stash() }); r = createRunner(b); o = await r.run('inv.store', { items: 'iron_pickaxe,dirt' })
  ok(o.ok && o.data.moved.iron_pickaxe === 1 && o.data.moved.dirt === 10 && !o.data.moved.cobblestone, 'store: daftar eksplisit menimpa keepTools dan hanya memindah yang disebut')
  b = mkInv({ inv: stash() }); r = createRunner(b); o = await r.run('inv.store', { keep: 'bread,dirt' })
  ok(o.ok && !o.data.moved.bread && !o.data.moved.dirt && o.data.moved.cobblestone === 100, 'store: keep menahan item tertentu')
  b = mkInv({ inv: stash() }); r = createRunner(b); o = await r.run('inv.store', { items: 'cobblestone,diamond' })
  ok(o.ok && o.data.moved.cobblestone === 100 && o.data.skipped.some(s => s.item === 'diamond' && /tidak ada/.test(s.why)), 'store: item yang diminta tapi tidak dimiliki dilaporkan')
  b = mkInv({ inv: stash(), chest: Object.fromEntries(Array.from({ length: 27 }, (_, i) => [i, ['gravel', 64]])) }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /penuh/.test(o.error) && o.data.chestFull && inv(b, 'cobblestone') === 100, 'store: chest penuh -> gagal jelas, tidak ada item hilang')
  b = mkInv({ inv: { 9: ['cobblestone', 64], 10: ['cobblestone', 36] }, chest: Object.fromEntries(Array.from({ length: 26 }, (_, i) => [i, ['gravel', 64]])) }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(o.ok && o.data.moved.cobblestone === 64 && o.data.failed.length === 1 && /64\/100/.test(o.data.failed[0].error) && inv(b, 'cobblestone') + chestCount(b, 'cobblestone') === 100, 'store: chest hampir penuh -> sebagian terpindah (64/100), jumlah total tetap 100')
  b = mkInv({ inv: { 36: ['iron_pickaxe', 1] } }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /tidak ada item/.test(o.error), 'store: hanya alat -> tidak ada yang dipindah')
  b = mkInv({ inv: stash(), blocks: [] }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'TARGET_NOT_FOUND' && inv(b, 'cobblestone') === 100, 'store: tanpa chest -> TARGET_NOT_FOUND, inventory utuh')
  b = mkInv({ inv: stash(), noOp: true }); r = createRunner(b); o = await r.run('inv.store', { items: 'dirt' })
  ok(o.ok && o.data.moved.dirt === 10 && o.data.verify.checked === false && o.data.movedBy === 'bot', 'store: tanpa op tetap memindah (dihitung dari inventory bot), verifikasi server dilewati')
  b = mkInv({ inv: stash(), noOp: true }); r = createRunner(b); o = await r.run('inv.store', { includeModded: true })
  ok(o.ok && o.data.moved.cobblestone === 100 && !o.data.moved['touhou_little_maid:bell'] && o.data.skipped.some(s => /butuh op/.test(s.why)), 'store: includeModded tanpa op -> item modded dilewati dengan alasan "butuh op", vanilla tetap pindah')
  b = mkInv({ inv: { 14: ['unknown', 2, 7777, 'mod:widget'] } }); r = createRunner(b); o = await r.run('inv.store', { includeModded: true })
  ok(o.ok && o.data.moved['mod:widget'] === 2 && o.data.method.click === 1 && chestIdCount(b, 'mod:widget') === 2 && srvInvCount(b, 'mod:widget') === 0, 'store: includeModded + op -> item modded dipindah lewat shift-click berbasis slot (terhitung dari server)')
  ok(b.writes.some(w => w.name === 'window_click' && w.mode === 1 && w.slot === 27 + (14 - 9) && w.windowId === 7), 'store: paket shift-click memakai nomor slot jendela yang benar (inventoryStart + slot - 9)')
  b = mkInv({ inv: { 0: ['dirt', 3], 5: ['dirt', 9], 45: ['dirt', 4], 9: ['dirt', 1] } }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(o.ok && o.data.moved.dirt === 1 && b.inventory.slots[5].count === 9 && b.inventory.slots[45].count === 4 && b.inventory.slots[0].count === 3, 'store: slot crafting/armor/tangan kiri tidak disentuh')
  b = mkInv({ inv: { 9: ['hidden', 1] }, hiddenInv: [{ slot: 15, id: 'minecraft:oak_log', count: 30 }, { slot: 16, id: 'sophisticatedbackpacks:backpack', count: 1, comps: { 'sophisticatedbackpacks:storage_contents': 'x' } }] }); b.inventory.slots[9] = null; b._srvInv[9] = null; r = createRunner(b)
  o = await r.run('inv.store', {})
  ok(o.ok && o.data.moved.oak_log === 30 && o.data.method.click === 1 && o.data.skipped.some(s => s.item === 'sophisticatedbackpacks:backpack' && s.why === 'modded'), 'store: item vanilla yang TIDAK terbaca bot (dibawa sebelum spawn) tetap dipindah lewat data server')
  b = mkInv({ inv: stash(), lagMs: 300, noOp: true }); r = createRunner(b); o = await r.run('inv.store', { items: 'cobblestone' })
  ok(o.ok && o.data.moved.cobblestone === 100, 'store: konfirmasi server lambat (300 ms) tidak membuat hasil dinilai gagal (settle)')

  // --- jendela degraded ---
  b = mkInv({ inv: stash(), degradedOpen: true }); r = createRunner(b); o = await r.run('inv.store', { includeModded: true })
  ok(o.ok && o.data.degraded && o.data.method.deposit === 0 && o.data.method.click >= 5 && o.data.moved.cobblestone === 100 && o.data.moved['touhou_little_maid:bell'] === 2 && o.data.verify.degraded, 'store degraded: semua dipindah lewat shift-click (vanilla + modded), terhitung dari server')
  ok(b._closedIds.includes(7) && b.currentWindow === null, 'store degraded: jendela ditutup lewat close_window mentah')
  b = mkInv({ inv: stash(), degradedOpen: true, noOp: true }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /butuh op|tidak ada item/.test(o.error) && b._closedIds.includes(7) && inv(b, 'cobblestone') === 100, 'store degraded tanpa op: tidak memindah apa pun, jelas alasannya, jendela ditutup')
  b = mkInv({ inv: stash(), ignoreClicks: true, degradedOpen: true }); r = createRunner(b); o = await r.run('inv.store', {})
  ok(!o.ok && o.code === 'SERVER_REJECTED' && b._closedIds.includes(7), 'store: server mengabaikan klik -> SERVER_REJECTED (tidak dikira berhasil)')

  // ================= inv.take =================
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12], 2: ['coal', 20] } }); r = createRunner(b)
  o = await r.run('inv.take', { item: 'coal', count: 60 })
  ok(o.ok && o.data.moved.coal === 60 && inv(b, 'coal') === 60 && chestCount(b, 'coal') === 10 && o.data.verify.ok && o.data.chestAfter.totals['minecraft:coal'] === 10 && o.data.granularity === 'exact', 'take: 60 coal dari 2 stack, sisa 10 di chest, verifikasi server cocok')
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal,iron_ingot', count: 'all' })
  ok(o.ok && o.data.moved.coal === 50 && o.data.moved.iron_ingot === 12 && chestCount(b, 'coal') === 0, 'take: dua item sekaligus dengan count=all')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal', count: 99 })
  ok(o.ok && o.data.moved.coal === 5, 'take: minta lebih dari ada -> ambil semua yang ada')
  b = mkInv({ chest: { 0: ['coal', 5], 1: ['bread', 2] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'diamond' })
  ok(!o.ok && o.code === 'TARGET_NOT_FOUND' && /tidak ada di chest: diamond/.test(o.error) && /coal x5/.test(o.error) && /bread x2/.test(o.error), 'take: item tak ada -> TARGET_NOT_FOUND + daftar isi chest')
  b = mkInv({ chest: { 0: ['coal', 5] }, inv: Object.fromEntries(Array.from({ length: 36 }, (_, i) => [i + 9, ['cobblestone', 64]])) }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal' })
  ok(!o.ok && o.code === 'INVENTORY_FULL' && chestCount(b, 'coal') === 5, 'take: inventory penuh -> INVENTORY_FULL, chest utuh')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'touhou_little_maid:bell' })
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && /includeModded/.test(o.error), 'take: item modded tanpa includeModded -> PRECONDITION_FAILED')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', {})
  ok(!o.ok, 'take: tanpa param item ditolak')
  b = mkInv({ chest: { 0: ['coal', 5] } }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal', count: 2, verify: false })
  ok(o.ok && o.data.moved.coal === 2 && o.data.verify.checked === false && o.data.movedBy === 'bot' && !(b.sent || []).length, 'take: verify=false -> tanpa perintah ke server')
  ok(r.parse('inv.take', ['coal', '3']).item === 'coal' && r.parse('inv.take', ['coal', '3']).count === 3, 'take: CLI posisional item count')
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12], 2: ['bread', 3] }, hiddenChest: [{ slot: 5, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }] }); r = createRunner(b)
  o = await r.run('inv.take', { item: 'all' })
  ok(o.ok && o.data.moved.coal === 50 && o.data.moved.iron_ingot === 12 && o.data.moved.bread === 3 && !o.data.moved['tacz:modern_kinetic_gun'] && o.data.skipped.some(s => s.item === 'tacz:modern_kinetic_gun' && s.why === 'modded') && chestIdCount(b, 'tacz:modern_kinetic_gun') === 1, 'take item=all: mengambil semua item vanilla, item modded dilewati tanpa includeModded')
  b = mkInv({ chest: { 0: ['coal', 50] }, hiddenChest: [{ slot: 5, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }] }); r = createRunner(b)
  o = await r.run('inv.take', { item: 'all', includeModded: true })
  ok(o.ok && o.data.moved.coal === 50 && o.data.moved['tacz:modern_kinetic_gun'] === 1 && o.data.method.click === 1 && chestIdCount(b, 'tacz:modern_kinetic_gun') === 0 && srvInvCount(b, 'tacz:modern_kinetic_gun') === 1, 'take item=all includeModded: item modded diambil lewat shift-click berbasis slot dari data server')
  b = mkInv({ chest: { 0: ['coal', 50] }, hiddenChest: [{ slot: 5, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }], noOp: true }); r = createRunner(b)
  o = await r.run('inv.take', { item: 'all', includeModded: true })
  ok(o.ok && o.data.moved.coal === 50 && !o.data.moved['tacz:modern_kinetic_gun'], 'take: tanpa op hanya item yang terbaca yang bisa diambil (tidak berpura-pura)')
  b = mkInv({ chest: { 0: ['coal', 50], 1: ['iron_ingot', 12] }, hiddenChest: [{ slot: 3, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }], degradedOpen: true }); r = createRunner(b)
  o = await r.run('inv.take', { item: 'coal' })
  ok(o.ok && o.data.degraded && o.data.moved.coal === 50 && o.data.granularity === 'stack' && inv(b, 'coal') === 50 && b._closedIds.includes(7), 'take degraded: vanilla diambil lewat shift-click per stack (terhitung dari server), jendela ditutup')
  b = mkInv({ chest: { 0: ['coal', 50] }, hiddenChest: [{ slot: 3, id: 'tacz:modern_kinetic_gun', count: 1, comps: { 'tacz:gun_id': 'x' } }], degradedOpen: true }); r = createRunner(b)
  o = await r.run('inv.take', { item: 'tacz:modern_kinetic_gun', includeModded: true })
  ok(o.ok && o.data.moved['tacz:modern_kinetic_gun'] === 1 && srvInvCount(b, 'tacz:modern_kinetic_gun') === 1, 'take degraded: item modded bernama ns:path diambil')
  b = mkInv({ chest: { 0: ['coal', 50] }, degradedOpen: true, noOp: true }); r = createRunner(b); o = await r.run('inv.take', { item: 'coal' })
  ok(!o.ok && o.code === 'PRECONDITION_FAILED' && b._closedIds.includes(7) && chestCount(b, 'coal') === 50, 'take degraded tanpa op: gagal jelas, chest utuh, jendela ditutup')

  // ================= engine.state =================
  b = mkInv({ inv: { 36: ['cobblestone', 37] }, hiddenInv: [{ slot: 41, id: 'sophisticatedbackpacks:backpack', count: 1, comps: { 'sophisticatedbackpacks:storage_contents': 'x' } }] }); b.put(20, 'unknown', 2, 6666, 'touhou_little_maid:power_point'); r = createRunner(b); const eng = createEngine(b, r)
  let st = eng.state()
  ok(st.inventory.source === 'protocol' && st.inventory.accurate === false && st.inventory.items.some(i => i.name === 'unknown#6666'), 'state: tanpa snapshot -> protocol, accurate=false, unknown#id')
  await r.run('inv.snapshot', {})
  st = eng.state()
  ok(st.inventory.source === 'snbt' && st.inventory.accurate === true && st.inventory.items.some(i => i.name === 'touhou_little_maid:power_point') && st.inventory.items.some(i => i.name === 'sophisticatedbackpacks:backpack') && st.inventory.items.some(i => i.name === 'cobblestone'), 'state: snapshot segar -> daftar = kebenaran server (termasuk item yang tak terbaca bot), nama tanpa minecraft:')
  b.arcadia.inventoryTruth.ts = Date.now() - 31000; st = eng.state()
  ok(st.inventory.source === 'protocol' && st.inventory.accurate === false, 'state: snapshot kedaluwarsa (>30 dtk) -> kembali protocol/accurate=false')
  b.arcadia.inventoryTruth.ts = Date.now(); b.arcadia.inventoryTruth.accurate = false; st = eng.state()
  ok(st.inventory.source === 'protocol', 'state: snapshot ditandai tidak valid -> protocol')
  b.arcadia.inventoryTruth.accurate = true
  const { validate } = require('../contracts/validate')
  ok(!validate('BotState', eng.state()), 'state: tetap valid terhadap kontrak BotState')

  fs.rmSync(TMP, { recursive: true, force: true })
  console.log('\nHASIL: ' + pass + ' lulus, ' + fail + ' gagal')
  process.exit(fail ? 1 : 0)
})().catch(e => { console.log('EXCEPTION', e); process.exit(1) })
