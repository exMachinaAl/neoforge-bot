const fs = require('fs')
const U = require('./_util')
const I = require('./_inv')
const names = require('./_names')

const manifest = {
  name: 'inv.snapshot',
  description: 'Bandingkan inventory bot (protokol) dengan data server (/data get entity Inventory); belajar nama item modded; butuh bot op',
  paramsSchema: {
    type: 'object',
    properties: {
      waitMs: { type: 'integer', minimum: 1000, maximum: 20000, default: 6000 },
      save: { type: 'boolean', default: true, description: 'tulis snapshot.json' },
      hydrate: { type: 'boolean', default: true, description: 'isi slot inventory bot yang hilang dengan item polos (tanpa komponen) dari data server' }
    }
  },
  requires: ['inventory.protocol', 'inventory.snbt', 'chat'],
  interruptible: true,
  estimatedMs: 3000
}

const cap = (a, n = 20) => a.slice(0, n)

async function run (bot, p, ctx) {
  const t0 = Date.now()
  const sv = await I.serverInventory(bot, { timeoutMs: p.waitMs || 6000, signal: ctx.signal })
  if (!sv.ok) return sv
  let view = I.botView(bot)
  let d = I.diffSlots(view, sv.items.filter(x => x.slot != null))
  const unmapped = sv.items.filter(x => x.slot == null).map(x => ({ nbtSlot: x.nbtSlot, id: x.id, count: x.count }))

  // hidrasi: paket inventory bermuatan komponen modded dibuang bot, jadi item yang sudah dibawa sebelum spawn tak terbaca.
  // Item polos (tanpa komponen) bisa direkonstruksi dari data server; yang bermuatan komponen tidak (butuh skema komponen).
  const hydrated = []; const unreadable = []
  if (p.hydrate !== false && d.missing.length) {
    const Item = require('prismarine-item')(bot.registry)
    for (const m of d.missing) {
      const x = sv.items.find(y => y.slot === m.slot); if (!x) continue
      if (x.comps.length) { unreadable.push({ slot: x.slot, id: x.id, count: x.count, comps: x.comps.slice(0, 6) }); continue }
      const sh = I.shortId(x.id)
      const type = ctx.mcData.itemsByName[sh] ? ctx.mcData.itemsByName[sh].id : names.idOf(x.id)
      if (type == null) { unreadable.push({ slot: x.slot, id: x.id, count: x.count, why: 'id numerik tidak diketahui' }); continue }
      try { bot.inventory.updateSlot(x.slot, new Item(type, x.count, null, null)); hydrated.push({ slot: x.slot, id: x.id, count: x.count }) } catch (e) { unreadable.push({ slot: x.slot, id: x.id, count: x.count, why: e.message.slice(0, 60) }) }
    }
    if (hydrated.length) { view = I.botView(bot); d = I.diffSlots(view, sv.items.filter(x => x.slot != null)) }
  }

  // belajar nama: slot yang di sisi bot bernama unknown#<id> tetapi server menyebut nama aslinya
  const learned = {}
  for (const u of d.unknownId) {
    const it = bot.inventory.slots[u.slot]
    if (it && names.learn(it.type, u.id)) learned[it.type] = u.id
  }
  if (Object.keys(learned).length) names.save()

  const truthTotals = I.totalsOf(sv.items)
  const botTotals = I.totalsOf(view)
  const ok = I.accurate(d) && !unmapped.length
  const modded = sv.items.filter(x => I.isModdedId(x.id) || x.comps.some(I.isModdedId))
  const data = {
    accurate: ok, serverItems: sv.items.length, botItems: view.length, matched: d.match,
    protocolEmpty: view.length === 0 && sv.items.length > 0,
    missingInBot: cap(d.missing), extraInBot: cap(d.extra), idDiff: cap(d.idDiff), countDiff: cap(d.countDiff), unknownNamed: cap(d.unknownId),
    moddedOrComponent: cap(modded.map(x => ({ slot: x.slot, id: x.id, count: x.count, comps: x.comps.slice(0, 6) })), 12),
    unmappedSlots: cap(unmapped),
    hydrated: cap(hydrated), unreadable: cap(unreadable),
    learned, names: names.stats(), truthTotals, botTotals
  }
  bot.arcadia = bot.arcadia || {}
  // daftar ini = kebenaran server saat snapshot (lengkap, termasuk item yang tak terbaca bot); 'matched' = tampilan bot cocok penuh
  bot.arcadia.inventoryTruth = { ts: Date.now(), accurate: true, matched: ok, totals: truthTotals, items: sv.items.map(x => ({ slot: x.slot, id: x.id, count: x.count })) }
  if (p.save !== false) { try { fs.writeFileSync(I.dataPath('snapshot.json'), JSON.stringify({ ts: Date.now(), accurate: ok, server: sv.items, diff: d }, null, 1)) } catch (e) { /* abaikan */ } }
  data.durationMs = Date.now() - t0
  if (hydrated.length) data.hydratedNote = hydrated.length + ' slot dipulihkan ke tampilan bot dari data server (item polos)'
  if (!ok) data.note = 'inventory bot berbeda dari server: ' + d.missing.length + ' hilang di bot (' + unreadable.length + ' tak bisa dipulihkan: bermuatan komponen), ' + d.extra.length + ' lebih di bot, ' + (d.idDiff.length + d.countDiff.length) + ' selisih, ' + unmapped.length + ' slot tak terpetakan'
  return { ok: true, code: 'OK', data }
}

module.exports = { manifest, run, cli: [] }
